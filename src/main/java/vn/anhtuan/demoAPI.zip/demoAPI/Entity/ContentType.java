package vn.anhtuan.demoAPI.Entity;

public enum ContentType {
    TEXT, IMAGE;
}
